Surface Laptop 4 Intel — данные Dolby из Windows для macOS APOMac

Профили созданы из оригинального XML 10EC:123E, коррекция L/R сохранена.
Подготовлены: Clear Speech (+1.88 dB, 2500 Hz), Balanced, Detailed, Warm, Voice.
В динамических профилях применяется FIR-коррекция динамиков. Профиль Voice
в исходном Dolby отключает audio-optimizer: для обычного просмотра видео
рекомендуется начать с Clear Speech или Balanced.

В macOS: APOMac 0.1.0 (Intel, Tahoe >=15). Откройте его и разрешите
System Audio Recording. Скопируйте папки с config.txt в ~/APOMac.
Выберите Clear Speech, привяжите к встроенному аудиовыходу через Device.
Кнопка Bypass (Cmd+B) сравнивает до/после. Для отмены достаточно
выключить/удалить профиль либо закрыть APOMac. Система/Windows не меняются.
Штатные Dolby DRC, регулятор и автогейн не переносились; DSP не полностью
идентичен Windows. Требуется проверить на том же Surface после загрузки macOS.

В архив включён Install-on-macOS.command: проверяет CPU/i7-1185G7,
Tahoe 26.7.1, копирует профили в ~/APOMac без замены существующих.
