#!/bin/zsh
# Safe local-only APOMac profile importer for the exact Intel Surface Laptop 4.
# Never replaces AppleALC, coreaudiod, EFI, Windows or any audio driver.
set -euo pipefail
src="$(cd "$(dirname "$0")" && pwd)"
if [[ "$(uname -s)" != "Darwin" ]]; then print -u2 "Use this after booting macOS"; exit 2; fi
cpu="$(/usr/sbin/sysctl -n machdep.cpu.brand_string)"
if [[ "$cpu" != *"i7-1185G7"* ]]; then print -u2 "Different CPU: refusing to install laptop-specific correction"; exit 3; fi
os="$(/usr/bin/sw_vers -productVersion)"
if [[ "$os" != "26.7.1" ]]; then print -u2 "Current macOS $os untested; refusing"; exit 4; fi
for d in "$src"/Surface\ Laptop\ 4\ -\ *; do
  [[ -f "$d/config.txt" && -f "$d/speaker-correction.wav" ]] || { print -u2 "Incomplete exported profile: $d"; exit 5; }
done
dst="$HOME/APOMac"
mkdir -p "$dst"
for d in "$src"/Surface\ Laptop\ 4\ -\ *; do
  target="$dst/${d:t}"
  if [[ -e "$target" ]]; then
    print -u2 "Existing profile preserved, skipping: $target"
    continue
  fi
  /usr/bin/ditto "$d" "$target"
  a="$(/usr/bin/shasum -a 256 "$d/speaker-correction.wav" | /usr/bin/awk '{print $1}')"
  b="$(/usr/bin/shasum -a 256 "$target/speaker-correction.wav" | /usr/bin/awk '{print $1}')"
  [[ "$a" == "$b" ]] || { print -u2 "FIR copy failed SHA256 check"; exit 6; }
  print "IMPORTED: ${d:t}"
done
print "The profiles are copied into $dst."
print "Install/open APOMac, allow System Audio Recording and select Clear Speech."
print "IMPORTANT: bind profile to Built-in Output (Device control), not headphones/HDMI."
print "APOMac Cmd+B bypass compares original audio. Quit APOMac to restore original sound."
