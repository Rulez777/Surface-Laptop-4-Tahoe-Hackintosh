Surface Laptop 4 Intel — WhateverXe 0.8.3 EDP Keep + Softsleep
================================================================

Tested 2026-11-23 on Surface Laptop 4 Intel 13.5":
 i7-1185G7, Iris Xe PCI 8086:9A49, macOS Tahoe 26.7.1, OpenCore 1.0.8.
 Requires a booting installed macOS Tahoe with working Metal 2 and WhateverXe 0.8.3.
 This is a post-install add-on, not a complete Hackintosh EFI or macOS installer.

This package contains:
 - WhateverXe.kext: custom v0.8.3, SHA-256 0796d12158b9c6806a83e4f455f84eee9280a0148406b8d4f0764234f00df91a
 - install_edp_keep_macos.py: hardware-limited install/check/rollback with backups
 - tools/ocvalidate: official OpenCore 1.0.8 config validator
 - LICENSE-WHATEVERXE.txt: upstream license
 - SOURCE.txt: upstream patch and build provenance

This installer does NOT contain an OpenCore config.plist, serial number, SMBIOS,
UUID or anyone's Windows/EFI installation.

QUICK START (after extracting the archive in macOS):
  diskutil list
  sudo python3 install_edp_keep_macos.py check --esp disk0s1
  sudo python3 install_edp_keep_macos.py apply --esp disk0s1

Replace disk0s1 with YOUR INTERNAL EFI System Partition identifier.
Reboot into macOS after apply. If needed, rollback in macOS:
  sudo python3 install_edp_keep_macos.py rollback --esp disk0s1

The installer checks the exact Intel GPU, CPU, installed framebuffer donor,
Lilu and WhateverXe versions, validated boot flags, and internal EFI.
It copies the entire existing EFI/OC into ~/Downloads/SL4-EDP-BACKUPS,
keeps the previous kext and writes an additional recovery config into EFI/OC.
It edits only EFI/OC and never EFI/Microsoft, firmware NVRAM or partitions.
It validates OpenCore config both before and after the change.

At present: physical display-only sleep/wake is user-confirmed with the
power button and by closing and reopening the lid on the tested Surface.
These observations DO NOT establish true S3/S0ix system sleep. The tested
machine still has pmset sleep=0 and displaysleep=0 to avoid unattended
failures. DO NOT enable S3, S0ixStandby, SSDT-DEEPIDLE, or turn on lid
sleep based only on this limited display-wake validation. Do not place
a running laptop in a bag based on these results.

Driver implementation:
 - eDP Keep: preserves the live Tiger Lake eDP link when it matches the
   requested resolution/mode, avoiding destructive full retraining.
 - Softsleep: preserves link/panel power while turning off backlight.
 - WakeTrace: read-only lifecycle telemetry and error diagnostics.
 - Previously validated TGL GPU-recovery and stamp fixes retained.

Only qualified for the exact machine + verified donor SHA-256
115a4616e862228a8c82df6e52ba41ac02b9750f116352ff3575aadcc950888e.
Other Surface sizes, generations, GPUs, macOS and donors are untested;
the installer fails closed rather than guessing compatibility.

For step-by-step setup and troubleshooting:
https://github.com/Rulez777/Surface-Laptop-4-Tahoe-Hackintosh
