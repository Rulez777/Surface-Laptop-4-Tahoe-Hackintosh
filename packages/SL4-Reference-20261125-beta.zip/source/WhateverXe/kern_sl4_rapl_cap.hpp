#pragma once
#include <stdint.h>
namespace SL4RAPL {
constexpr uint64_t Field=0x7fffULL,Mask=Field|(Field<<32),Lock=1ULL<<63,Enable1=1ULL<<15,Enable2=1ULL<<47;
enum Status:uint64_t {Unavailable,Locked,Disabled,Invalid,Already,Candidate,Verified,Mismatch,Observe};
struct Decision {uint64_t raw;Status status;};
inline Decision lower(uint64_t units,uint64_t raw) {
 if(raw&Lock)return {raw,Locked};
 if(!(raw&Enable1)||!(raw&Enable2))return {raw,Disabled};
 unsigned e=units&15;
 if(e>10)return {raw,Invalid};
 uint64_t a=raw&Field,b=(raw>>32)&Field,pl1=18ULL<<e,pl2=30ULL<<e;
 if(!a||!b||b<a||pl1>Field||pl2>Field)return {raw,Invalid};
 uint64_t n=(raw&~Mask)|(a<pl1?a:pl1)|((b<pl2?b:pl2)<<32);
 return {n,n==raw?Already:Candidate};
}
}
