#pragma once
/* Experimental local-only Surface Laptop 4 TGL DMC v2.12 loader.
 * This is NOT activated unless the explicitly opt-in WEX hook qualifies the
 * donor image, and no live EFI or MMIO write is performed by the build.
 * See scripts/inspect_tgl_dmc.py for verified fixed-size MMIO layout.
 */
#include <stdint.h>
#include "kern_sl4_dmc_trial_data.hpp"

namespace SL4DMCTrial {
static constexpr uint64_t kManagerOffset=0xC40;
static constexpr uint32_t kExpectedFirst=0x0C004040;
static constexpr uint32_t kExpectedSSP=0x00086FC0;
static constexpr uint32_t kExpectedEvtB4=0xC003B400;
using WriteFn=void (*)(void *,unsigned long,uint32_t);
using ReadFn=uint32_t (*)(void *,unsigned long);

static bool upload(void *controller,uintptr_t writeAddress,uintptr_t readAddress,uint32_t *verify) {
    if (!controller || !writeAddress || !readAddress) return false;
    if (SL4TGLDMC::kProgramDwords!=4460 ||
        SL4TGLDMC::kProgram[0]!=kExpectedFirst ||
        SL4TGLDMC::kLoadAddress!=0x80000 ||
        SL4TGLDMC::kMmioWriteCount!=9 ||
        SL4TGLDMC::kMmioWrites[0].addr!=0x8F074 ||
        SL4TGLDMC::kMmioWrites[0].data!=kExpectedSSP ||
        SL4TGLDMC::kMmioWrites[1].data!=kExpectedEvtB4)
        return false;
    void *mgr=*reinterpret_cast<void **>(
        reinterpret_cast<uint8_t *>(controller)+kManagerOffset);
    if (!mgr) return false;
    auto wr=reinterpret_cast<WriteFn>(writeAddress);
    auto rd=reinterpret_cast<ReadFn>(readAddress);
    // The framebuffer has already configured the display/clock powers
    // through the original donor. We replace ONLY its DMC program.
    for (uint32_t i=0;i<SL4TGLDMC::kProgramDwords;i++) {
        wr(mgr,static_cast<unsigned long>(SL4TGLDMC::kLoadAddress)+4UL*i,
           SL4TGLDMC::kProgram[i]);
    }
    for(uint32_t i=0;i<SL4TGLDMC::kMmioWriteCount;i++) {
        uint32_t value=SL4TGLDMC::kMmioWrites[i].data;
        // Validated TGL i915 DMC event correction: VBLANK_A (0x32)
        // must be delayed-VBLANK_A (0x2e) for the HRR handler.
        if(SL4TGLDMC::kMmioWrites[i].addr==0x8F03C &&
           value==0xC0033200)
            value=0xC0032E00;
        wr(mgr,SL4TGLDMC::kMmioWrites[i].addr,value);
    }
    const uint32_t back=rd(mgr,0x80000);
    if (verify)*verify=back;
    return back==kExpectedFirst;
}
}
