#include "../WhateverXe/kern_sl4_rapl_cap.hpp"
#include <cassert>
#include <cstdio>
int main(){
 using namespace SL4RAPL;
 uint64_t c=Enable1|Enable2|(1ULL<<16)|(0x53ULL<<17)|(0x21ULL<<49);
 uint64_t r=c|240ULL|(480ULL<<32);
 auto d=lower(3,r);assert(d.status==Candidate);
 assert((d.raw&Field)==144 && ((d.raw>>32)&Field)==240);
 assert((d.raw&~Mask)==(r&~Mask));
 assert(lower(3,r|Lock).status==Locked);
 assert(lower(3,r&~Enable1).status==Disabled);
 assert(lower(3,r&~Enable2).status==Disabled);
 assert(lower(3,c).status==Invalid);
 assert(lower(3,c|100|(80ULL<<32)).status==Invalid);
 uint64_t low=c|80ULL|(160ULL<<32);assert(lower(3,low).raw==low&&lower(3,low).status==Already);
 assert((lower(3,c|80ULL|(480ULL<<32)).raw&Field)==80);
 for(unsigned e=0;e<=10;++e){auto n=lower(e,c|Field|(Field<<32));assert(n.status==Candidate);assert((n.raw&~Mask)==c);assert((n.raw&Field)==(18ULL<<e));assert(((n.raw>>32)&Field)==(30ULL<<e));}
 uint64_t strict=c|120ULL|(200ULL<<32);assert(lower(3,strict).raw==strict);
 assert(lower(15,r).status==Invalid);
 puts("PASS: lower-only, lock/enable guards, Tau/clamp/reserved bits preserved");
}
